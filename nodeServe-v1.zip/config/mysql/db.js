class Connect {
    //构造函数
    constructor() {
        this.mysql = require('mysql');
        var { connConfig } = require('../config');
        this.connection = this.mysql.createConnection({
            host: connConfig.host,
            user: connConfig.user,
            password: connConfig.password,
            database: connConfig.database
        })
        this.connection.connect(err => {
            if (err) {
                console.error('error connecting: ' + err.stack);
                return;
            }
        })
    }

    query(sql) {

        }
        /*
            select id,name from table where  = like betweem join order
            array:查询参数
            table：表
            where:条件 {key:value}
            link:连接
        */
    select(field = [], table = '', where = {}, order = '', limit = [], link = '') {
        let sql = 'select';
        if (field.length == 0) {
            sql += ' * ';
        } else {
            field.forEach((item, index) => {
                if (index == 0) {
                    sql += item;
                } else {
                    sql += ',' + item;
                }
            })
        }
        sql += 'FROM ' + table;
        if (where) {
            sql += this.handleWhere(where, link);
        }
        if (order) {
            sql += ' ORDER BY ' + order;
        }
        if (limit) {
            sql += ' LIMIT ' + limit[0] + ',' + limit[1];
        }
        return this.operation(sql)
    }

    insert(dataInfo, table) {
        let sql = "INSERT INTO " + table + "(";
        let keys = [];
        let values = [];
        Object.keys(dataInfo).forEach(key => {
            keys.push(key)
            values.push(String("'" + dataInfo[key] + "'"))
        })
        let keyStr = keys.join(',');
        let valueStr = values.join(',');
        sql += keyStr + ') ';
        sql += " VALUES(" + valueStr + ")";
        return this.operation(sql)
    }

    handleWhere(where, link) {
        let str = '';
        let whereArr = [];
        Object.keys(where).forEach(key => {
            if (typeof where[key] == 'object') {
                if (where[key][0] == 'like') {
                    whereArr.push(String((key + " like '" + where[key][1] + "'")));
                } else if (where[key][0] == 'gt') {
                    whereArr.push(String((key + " > " + where[key][1] + " ")));
                } else if (where[key][0] == 'lt') {
                    whereArr.push(String((key + " < " + where[key][1] + " ")));
                }
            } else if (typeof where[key] == 'number') {
                whereArr.push(String((key + " = " + where[key])));
            } else {
                whereArr.push(String((key + " = '" + where[key] + "'")));
            }

        })
        if (link) {
            let whereStr = whereArr.join(" " + link + " ");
            str += " WHERE " + whereStr;
        } else {
            let whereStr = whereArr.join(" AND ");
            str += " WHERE " + whereStr;
        }
        return str
    }

    operation(sql) {
        return new Promise((resolve, reject) => {
            this.connection.query(sql, (error, result, fields) => {
                if (error) {
                    reject(error)
                } else {
                    resolve(result)
                }
            })
        })
    }

}
var test = new Connect();
console.log(test.select([], 'tp_goods', { cat_id: 12, goods_remark: '4', goods_name: ['like', '%A%'], goods_id: ['gt', 0] }, 'goods_id desc', [0, 100]))
    // module.exports = Connect;